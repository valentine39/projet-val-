# 📊 Dashboard Économique Multi-Pays

Application Streamlit de tableau de bord économique, inspirée du dashboard analytique HTML Timor-Leste.

## 🎯 Fonctionnalités

- **Sélection dynamique** de n'importe quel pays via l'API Banque Mondiale
- **KPIs** mis à jour automatiquement avec les dernières données disponibles
- **Graphiques interactifs** (Plotly) : séries temporelles, histogrammes
- **Navigation par piliers** : Socioéco, Croissance, Finances, Équilibres externes
- **Tableau sourcé** avec liens cliquables vers les indicateurs WDI
- **Gestion des données manquantes** : jamais de page blanche

## 🏗️ Architecture

```
dashboard_eco/
├── app.py                  # Interface Streamlit principale
├── config.py               # Indicateurs, labels, métadonnées, couleurs
├── requirements.txt
├── README.md
├── scrapers/
│   ├── __init__.py
│   ├── base_scraper.py     # Classe abstraite (extensible)
│   └── banque_mondiale.py  # API Banque Mondiale (WDI)
└── services/
    ├── __init__.py
    └── data_service.py     # Orchestration, formatage, KPIs
```

## 🚀 Lancement local

```bash
git clone <votre-repo>
cd dashboard_eco

# Créer l'environnement virtuel
python -m venv .venv

# Activer (Windows)
.venv\Scripts\activate

# Activer (Mac / Linux)
source .venv/bin/activate

# Installer les dépendances
pip install -r requirements.txt

# Lancer l'app
streamlit run app.py
```

L'application s'ouvre sur http://localhost:8501

## 🧪 Tests recommandés

| Pays | Code | Particularité |
|------|------|---------------|
| Timor-Leste | TL | Données partielles — pays fragile |
| France | FR | Données complètes |
| Comoros | KM | Petit État insulaire |
| Japan | JP | Données historiques longues |

## 📊 Indicateurs Phase 1 (Banque Mondiale)

| Code | Label | Unité |
|------|-------|-------|
| NY.GDP.MKTP.CD | PIB nominal | Md USD |
| NY.GDP.PCAP.CD | PIB par habitant | USD |
| NY.GDP.MKTP.KD.ZG | Croissance PIB réel | % |
| FP.CPI.TOTL.ZG | Inflation (IPC) | % |
| SL.UEM.TOTL.ZS | Chômage | % |
| SP.POP.TOTL | Population | M hab. |
| SP.DYN.LE00.IN | Espérance de vie | ans |
| SP.DYN.IMRT.IN | Mortalité infantile | ‰ |
| GC.BAL.CASH.GD.ZS | Solde budgétaire | % PIB |
| GC.DOD.TOTL.GD.ZS | Dette publique | % PIB |
| BN.CAB.XOKA.GD.ZS | Compte courant | % PIB |
| BX.KLT.DINV.WD.GD.ZS | IDE entrants | % PIB |

## 🔧 Ajouter une source (Phase 2)

1. Créer `scrapers/fmi.py` héritant de `BaseScraper`
2. Implémenter `fetch_indicator()` et `fetch_countries()`
3. Ajouter les indicateurs dans `config.py` avec leur `source`
4. Référencer le scraper dans `services/data_service.py`

Sources prévues : FMI WEO · Freedom House · V-Dem · WGI · ADB
